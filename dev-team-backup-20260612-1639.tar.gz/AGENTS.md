# AGENTS.md - Jinjer PHP8 Agent Entrypoint

This file is the root entrypoint for agents working in `{{REPO_ROOT}}`.
Detailed rules, repository context, review guides, templates, and workflow references are maintained under `.agents/`.

Do not duplicate `.agents` content here. When a rule changes, update the source file under `.agents/` and keep this file as an index.

## Required Context

Read these files first:

- `.agents/core-context.md`
- `.agents/skills/jinjer-agent-orchestrator/SKILL.md`

## Rule Sources

- Development basics: `.agents/rules/development-basic.md`
- Design rules: `.agents/rules/development-design.md`
- Implementation rules: `.agents/rules/development-implement.md`
- Refactoring rules: `.agents/rules/development-refactor.md`
- Test basics: `.agents/rules/test-basic.md`
- Test design: `.agents/rules/test-design.md`
- Test implementation: `.agents/rules/test-implement.md`
- PR pre-check: `.agents/rules/pr-precheck.md`

## Repository Context

- `jinjer_hr_core`: `.agents/repositories/jinjer_hr_core.md`
- `jinjer_hr_auth`: `.agents/repositories/jinjer_hr_auth.md`
- `jinjer_hr_authentication`: `.agents/repositories/jinjer_hr_authentication.md`
- `jinjer_hr_jinji`: `.agents/repositories/jinjer_hr_jinji.md`
- `jinjer_jinji_common`: `.agents/repositories/jinjer_jinji_common.md`

## Review And Documentation

- Code review guide: `.agents/review/code-review-guide.md`
- Reviewer persona: `.agents/review/reviewer-persona.md`
- Design/test/sequence formats: `.agents/formats/design-and-test-formats.md`
- Permission map notes: `.agents/product/permission-maps.md`

## Templates

- Blocker report: `.agents/templates/blocker-template.md`
- Context summary: `.agents/templates/context-summary-template.md`
- PR description: `.agents/templates/pr-description-template.md`
- Task ticket notes: `.agents/templates/task-ticket-template.md`

## Operating Notes

- User-facing output should be Vietnamese unless the user asks otherwise.
- Preserve Japanese/Vietnamese business terms used by the project.
- Each service is a separate repository with its own dependencies and git history.
- Use Docker-based validation when possible.
- Check git status before editing and do not overwrite local changes.
- Không sử dụng Browser/manual QA trên Jinji.
- Không scan lại .dev-team/task-flows nếu không được yêu cầu.
- Chỉ đọc các file được nhắc tới trong .dev-team/task-flows.
- Không check git status tại thư mục root là PHP8 vì đây không phải thư mục làm việc chính.