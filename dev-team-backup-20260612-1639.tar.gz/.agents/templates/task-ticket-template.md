# <TASK> ticket notes

## Basic info
- Ticket: <TASK>
- Title:
- Type:
- Status:
- Priority:
- Sprint/release:

## Goal / expected behavior

## Current behavior / problem

## Reproduction / conditions

## Affected repos/files

## Data/API changes

## Implementation policy

## Test plan

## Open questions

## Work log
