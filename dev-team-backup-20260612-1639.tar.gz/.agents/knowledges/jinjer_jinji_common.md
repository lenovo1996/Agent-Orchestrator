# `jinjer_jinji_common`

#### Master setting import menu options cần common constants + fields — 2026-06-11
- **Context:** `人事設定` CSV import dropdown/template fields in Jinji.
- **Issue:** Adding entries only in `assets/templates/hr/js/import/*.js` is not enough; import dropdown and template columns are sourced from `MENU_DETAIL_SETTING_HR_IMPORT` and `config/fields.php` in `jinjer_jinji_common`.
- **Solution/Pattern:** Add the `menu_detail` label to `application/modules/common/config/constants.php`, field labels/required fields to `application/modules/common/config/fields.php`, and route special field sets in `application/modules/common/controllers/Import.php` when not using the default attendance fields.
- **Source:** `application/modules/common/controllers/Import.php`

#### `accounting_dept` import label spec mismatch — 2026-06-12
- **Context:** JH-40515 `人事設定` import dropdown verification against `spec/インポート画面設計.html`.
- **Issue:** Codebase labels key `accounting_dept` as `計上部門`, while the import screen spec/custom requirement says dropdown 2 should show `形状部門`. Static menu checks can pass by key but still fail spec text acceptance.
- **Solution/Pattern:** When verifying import menu completeness, check both preserved key `accounting_dept` and displayed label. If product confirms spec text, update display labels consistently in common constants, active/template JS, and `import_step_1.php` without renaming the key.
- **Source:** `config/constants.php`, `assets/hr/js/import/import_index.js`, `views/import/import_step_1.php`
