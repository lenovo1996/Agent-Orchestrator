# `jinjer_hr_core`

#### CI3 test framework `get_header()` không tương thích PHP8 — 2026-06-10
- **Context:** MasterSettingCsv export controller test, CSV download response
- **Issue:** `CI3 Output::get_header()` dùng `array_map('array_shift', $this->headers)` — `array_shift` cần pass-by-reference, gây error trên PHP 8.2. Không thể assert `Content-Type` header trực tiếp.
- **Test guideline:** Với CSV encoding tests, dùng BOM presence check (`substr($response, 0, 3) === "\xEF\xBB\xBF"`) thay vì assert Content-Type header. Áp dụng cho mọi test liên quan download/streaming response.
- **Source:** `application/tests/Containers/HRSection/MasterSettingCsv/API/Controllers/Controller.php`

#### `master_setting_details.code` là bigint — zero-padded strings bị normalize — 2026-06-10
- **Context:** MasterSettingCsv test data setup, insert + CSV assertion
- **Issue:** Column `code` là `bigint` — insert `'001'` → DB lưu `1` → CSV trả về `'1'`. Nếu dùng zero-padded string trong expected sẽ fail.
- **Test guideline:** Luôn dùng numeric code (không zero-padded) khi insert vào `master_setting_details` và trong expected CSV values.
- **Source:** `master_setting_details` table schema

#### Docker volume cache for new test directories — 2026-06-10
- **Context:** Adding new test directories under `application/tests/Containers/`
- **Issue:** New directories/files created on host are not immediately visible in the running Docker container (volume cache lag)
- **Solution/Pattern:** Use `cat localfile | docker exec -i container bash -c "cat > /containerpath"` to force-sync individual files; also run `docker exec container bash -c "mkdir -p /path"` to create dirs explicitly
- **Source:** MasterSettingCsv Services/Import test suites (JH-40515)

#### MasterSettingImportRegistry: hardcoded count assertions in tests — 2026-06-10
- **Context:** `ImportRegistryTestCase` — `supportedMenuDetails/count` and `menuDetailLabels/count`
- **Issue:** Both assertions hardcode the exact SCHEMAS count. Adding new entries without updating these will fail the test suite with a count mismatch.
- **Solution/Pattern:** Always update BOTH count assertions together when adding new SCHEMAS entries. After this ticket: count = 29.
- **Source:** `application/tests/Containers/HRSection/MasterSettingCsv/Import/TestSuite/ImportRegistryTestCase.php`

#### MasterSettingImport: pattern for extra-field types — 2026-06-10
- **Context:** `ValidateRowsTask`, `PersistRowsTask`, `MasterSettingImportRegistry`
- **Issue:** Adding a new type with an extra field requires changes in 4 places: Registry SCHEMAS + FIELD_HEADER_ALIASES, new Validator (composing BasicInfoRowValidator), ValidateRowsTask ternary + normalize(), PersistRowsTask buildExtra() switch.
- **Solution/Pattern:** Mirror `RecruitingClassificationRowValidator` for the validator. Add `mb_convert_kana` for the extra field in `normalize()` to handle full-width digits. Store extra as `json_encode($value)` for consistency.
- **Source:** `RecruitingClassificationRowValidator.php`, `WorkLocationRowValidator.php`

#### Running PHPUnit for jinjer_hr_core — 2026-06-10
- **Context:** Local vendor/ is empty; phpunit only available in Docker
- **Issue:** `./vendor/bin/phpunit` does not exist locally; running tests requires Docker container.
- **Solution/Pattern:** `docker exec hr_core bash -c "cd /usr/src/app && ./vendor/bin/phpunit -c ./application/tests --testsuite <name> --no-coverage"`
- **Source:** docker-compose.yml, hr_core container at `/usr/src/app`

#### MasterSettingCsv DB-backed suites share test DB state — 2026-06-11
- **Context:** Running `master_setting_csv_services` and `master_setting_csv` PHPUnit suites.
- **Issue:** Parallel suite execution can race on truncate/seed setup and fail with FK errors in `roles`, `role_permissions`, `companies`, or `job_titles`.
- **Solution/Pattern:** Run these MasterSettingCsv suites sequentially when using the shared Docker test DB.
- **Source:** `application/tests/Containers/HRSection/MasterSettingCsv/*/Controllers/Controller.php`

#### MasterSettingImport extra-field persistence cần DB/action tests — 2026-06-11
- **Context:** MasterSetting import fields lưu ngoài `master_setting_details`, ví dụ option `item_name` trong `master_setting.extra`.
- **Issue:** Registry/validator tests vẫn có thể pass dù `PersistRowsTask` hoặc `ImportMasterSettingCsvAction` persist master-level metadata sai hoặc filter valid rows sai.
- **Guideline:** Khi add/change import fields lưu trong `extra`, cần DB-backed coverage qua `PersistRowsTask`/`ImportMasterSettingCsvAction`, không chỉ registry và validator tests.
- **Source:** `application/services/MasterSettingImport/Tasks/PersistRowsTask.php`, `application/services/MasterSettingImport/Actions/ImportMasterSettingCsvAction.php`

#### Employee import tests need My Number DB migration — 2026-06-11
- **Context:** `Employee/RegisterUpdate/EmployeeController` import tests can load My Number service during employee import validation.
- **Issue:** Running only main `phinx.php -e testing` leaves `mon_numero.mon_numero` missing, causing import tests to fail before business assertions.
- **Solution/Pattern:** Run `php ./vendor/bin/phinx migrate -c phinx-mon-numero.php -e testing` before import employee PHPUnit filters when the test DB is fresh.
- **Source:** `phinx-mon-numero.php`, `application/tests/Containers/HRSection/Import/API/Controllers/Employee/RegisterUpdate/EmployeeController.php`

#### PHPUnit import testsuite has stale `.Containers` path — 2026-06-11
- **Context:** Running `./vendor/bin/phpunit -c ./application/tests --testsuite import --filter ...`.
- **Issue:** `application/tests/phpunit.xml` references `.Containers/HRSection/Import/API/Controllers/Employee/RegisterUpdate/EmployeeKintaiv2WorkingTimeController.php`, so the whole import testsuite can fail before the filter is applied.
- **Solution/Pattern:** Until the config is fixed, run scoped Employee import verification by direct file path: `./vendor/bin/phpunit -c ./application/tests ./application/tests/Containers/HRSection/Import/API/Controllers/Employee/RegisterUpdate/EmployeeController.php --filter <filter> --no-coverage`.
- **Source:** `application/tests/phpunit.xml`, `application/tests/Containers/HRSection/Import/API/Controllers/Employee/RegisterUpdate/EmployeeController.php`

#### CI PHPUnit ExitException type fatal on PHP 8 — 2026-06-12
- **Context:** Running focused controller PHPUnit in `hr_core`.
- **Issue:** `kenjis/ci-phpunit-test` fatal-errors before tests: `ExitException::$file must be string (as in class Exception)`.
- **Solution/Pattern:** Treat this as test-framework/environment blocker; rely on lint/static checks unless the framework patch is in scope.
- **Source:** `application/tests/_ci_phpunit_test/patcher/3.x/Exception/ExitException.php`

#### MasterSettingCsv export has contract-dependent columns — 2026-06-12
- **Context:** Master setting export, especially `payroll/payment_unit_cost`.
- **Issue:** `ExportMasterSettingCsvAction` conditionally sets `omit_price_classification` via `CheckPayrollContractTask`. New export APIs/actions that return raw data can accidentally expose enough data for callers to output a column the CSV spec says to omit.
- **Guideline:** Any new MasterSettingCsv export endpoint must preserve or explicitly expose this contract decision, and tests should cover company without payroll/expense contract.
- **Source:** `application/services/MasterSettingCsv/Actions/ExportMasterSettingCsvAction.php`, `application/services/MasterSettingCsv/Tasks/CheckPayrollContractTask.php`

#### Typed class constants break Docker PHP 8.2 — 2026-06-12
- **Context:** MasterSettingCsv services loaded by PHPUnit in `hr_core`.
- **Issue:** Syntax such as `private const string FOO` parses locally on newer PHP but fails in Docker PHP 8.2.
- **Solution/Pattern:** Use untyped class constants in project code until the Docker runtime is upgraded to PHP 8.3+.
- **Source:** `application/services/MasterSettingCsv/Support/MasterSettingCsvRegistry.php`

#### MasterSettingCsv suites may need test DB reseed after FK setup errors — 2026-06-12
- **Context:** Running `master_setting_csv` / `master_setting_csv_services` in Docker.
- **Issue:** If setup fails on `roles` / `role_permissions` / `job_titles` FK IDs, manual truncation can leave the test DB sequence/state inconsistent.
- **Solution/Pattern:** Run `docker exec hr_core bash -c "cd /usr/src/app && composer init_data_test"` before rerunning the suites sequentially.
- **Source:** `application/tests/TestCase.php::prepare_user_data()`, `Role_service::initial_role()`

#### MasterSettingCsv PHPUnit depends on restored test DB — 2026-06-12
- **Context:** Running `master_setting_csv_services` / `master_setting_csv` in Docker `hr_core`.
- **Issue:** If `jinjer_core_test` is missing or partially seeded, `composer init_data_test` can fail on missing seed prerequisites and PHPUnit may fail before assertions with DB bootstrap/FK errors.
- **Solution/Pattern:** Restore/migrate the configured test DB before rerunning these suites; do not treat FK/bootstrap failures during common setup as MasterSettingCsv business failures.
- **Source:** `composer init_data_test`, `application/tests/Containers/HRSection/MasterSettingCsv/*`

#### MasterSettingCsv suite order can require reseed with longer Composer timeout — 2026-06-12
- **Context:** Running `master_setting_csv` before `master_setting_csv_services` in Docker `hr_core`.
- **Issue:** The first suite can leave shared fixture tables truncated, causing the next suite to fail in `prepare_user_data()` with `roles.company_id` FK errors before business assertions. A follow-up `composer init_data_test` may also hit Composer's default 60s process timeout during `move_data_to_bank_master`.
- **Solution/Pattern:** Rerun `COMPOSER_PROCESS_TIMEOUT=300 composer init_data_test`, then run the suites sequentially. Treat the initial FK/setup error as fixture state unless it reproduces after the reseed.
- **Source:** `application/tests/Containers/HRSection/MasterSettingCsv/*`, `composer init_data_test`

#### `composer init_data_test` can timeout and leave test DB unavailable — 2026-06-12
- **Context:** Rerunning focused MasterSettingCsv PHPUnit in Docker `hr_core`.
- **Issue:** `composer init_data_test` can timeout at `move_data_to_bank_master` after seed duplicate-key output, and the next PHPUnit bootstrap may fail with unknown database `jinjer_core_test`.
- **Solution/Pattern:** Treat this as DB environment restoration work before PHPUnit; recreate/restore `jinjer_core_test` rather than debugging MasterSettingCsv assertions.
- **Source:** `composer init_data_test`, PHPUnit bootstrap database connection.
