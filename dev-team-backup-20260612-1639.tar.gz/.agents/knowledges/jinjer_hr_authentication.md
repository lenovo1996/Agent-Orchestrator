# `jinjer_hr_authentication` another name is `jinjer_hr_auth_core`
