# `jinjer_hr_jinji`

#### Import UI JS active path under common assets — 2026-06-11
- **Context:** `application/modules/common/controllers/Import.php` and `人事設定` import screen behavior.
- **Issue:** `Common_Controller` loads `common/templates`, so `set_js('js/import/import_index.js')` serves `application/modules/common/assets/hr/js/import/import_index.js`; editing only `assets/templates/hr/js/import/*` may not affect the active import screen.
- **Guideline:** For import UI behavior changes, verify/update the active `application/modules/common/assets/hr/js/import/*` path or run the established asset sync/build step, then static-check the active file.
- **Source:** `application/modules/common/controllers/Import.php`, `application/modules/common/libraries/Templates.php`

#### Common module active assets are git-ignored — 2026-06-11
- **Context:** `人事設定` import UI asset verification in `jinjer_hr_jinji`.
- **Issue:** `application/modules/common` is ignored by `.gitignore`, so active asset edits do not appear in `git status` even though local static checks read that path.
- **Solution/Pattern:** Keep tracked source changes in `assets/templates/hr/js/import/*`, then explicitly sync/check `application/modules/common/assets/hr/js/import/*` in the workspace before verification.
- **Source:** `.gitignore`, `application/modules/common/assets/hr/js/import/import_index.js`

#### Common import assets are ignored/generated — 2026-06-11
- **Context:** Jinji import screen active JS under `application/modules/common/assets/hr/js/import/*`.
- **Issue:** `application/modules/common` is ignored by `.gitignore`, so active asset syncs do not appear in `git status`/`git diff` even though the screen loads those files locally.
- **Solution/Pattern:** Keep tracked changes in `assets/templates/hr/js/import/*`, then sync or verify the ignored active common asset path before handoff.
- **Source:** `jinjer_hr_jinji/.gitignore`, `application/modules/common/assets/hr/js/import/import_index.js`

#### Nested common module has separate git status — 2026-06-11
- **Context:** Verifying import UI/common constants under `application/modules/common`.
- **Issue:** Parent `jinjer_hr_jinji` ignores `application/modules/common`, but that directory has its own `.git`; parent status hides common changes.
- **Guideline:** Run `git -C application/modules/common status` and `git -C application/modules/common diff` whenever common assets/config/controllers are touched.
- **Source:** `jinjer_hr_jinji/application/modules/common`

#### Import Step 1 multi-level select order — 2026-06-12
- **Context:** `人事設定` import UI with top menu, middle group, and leaf detail selects.
- **Issue:** `.format_item__content` renders selects in DOM order; showing `#js-midItems` without moving it before `.menu_details` displays leaf before group.
- **Guideline:** For 3-level import menus, keep DOM/order as top menu -> `#js-midItems` group -> `.menu_details` leaf and verify with a static order check.
- **Source:** `application/modules/common/views/import/import_step_1.php`, `application/modules/common/assets/hr/css/import/base.css`

#### Master setting export proxy must preserve Core CSV conditionals — 2026-06-12
- **Context:** `人事設定` export flow where Jinji proxies Core JSON and rebuilds CSV locally.
- **Issue:** Rebuilding CSV in Jinji can bypass behavior embedded in Core CSV actions/adapters, such as omitting `給与支給単価` `単価変動区分` when the company lacks payroll/expense contract.
- **Guideline:** When replacing Core CSV download with Jinji-built CSV, compare against `ExportMasterSettingCsvAction` and adapter conditionals, then add Jinji/proxy regression tests for contract-dependent columns.
- **Source:** `application/controllers/Master_setting_csv.php`, Core `ExportMasterSettingCsvAction.php`, `CheckPayrollContractTask.php`
