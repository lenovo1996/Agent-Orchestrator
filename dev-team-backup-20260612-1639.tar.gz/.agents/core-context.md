# AGENTS.md - Jinjer PHP8 Unified Agent Rules

This document consolidates all development rules, workflows, format guidelines, and repository context from the `.agents` repository into a single unified reference for AI agents and developers working on Jinjer PHP8 projects.

---

# Core Agent Instructions

## Jinjer HR system context

Jinjer is a microservice-based HR system. It is mainly built in PHP with CodeIgniter and follows a service-oriented architecture with multiple specialized services.

### Core services
- **jinjer_hr_core**: Main business logic and API endpoints for HR operations.
- **jinjer_hr_auth**: Authentication and authorization service.
- **jinjer_hr_authentication**: Dedicated authentication service with independent authentication features.
- **jinjer_hr_jinji**: HR administrator interface.
- **jinjer_admin**: Administration interface.

### Development environment
Use Docker Compose for local development with orchestration defined in `../jinjer_hr_docker/docker-compose.yml`. Each service runs in its own container with shared volumes and networks.

### Common development commands

```bash
# Start all services
cd <current path>/../jinjer_hr_docker && docker-compose up -d

# Install dependencies inside service
docker exec hr_core bash -c "composer install"

# Access service shell
docker exec -it hr_core bash
```

```bash
# Run migrations
composer migrate

# Create new migration
composer migration:create {table_name}
```

```bash
# Run full lint fix
composer lint-fix

# Run full test suite with coverage
composer test

# Run specific test suite
./vendor/bin/phpunit -c ./application/tests --testsuite <testsuite>
```

### Project structure
- `application/`: Main MVC application code.
  - `controllers/`: API and web controllers.
  - `models/`: Database models using Eloquent ORM.
  - `services/`: Business logic services.
  - `jobs/`: Background job classes.
  - `middleware/`: Authentication and authorization middleware.
  - `routes/`: Route definitions.
  - `validations/`: Input validation classes.
- `database/`: Migration files and seeds.
- `packages/`: Custom packages for electronic contracts and HR modules.
- `assets/`: Static assets for each module.

### Configuration files
- `composer.json`: Dependencies and scripts.
- `phinx.php`: Database migration settings.
- `ruleset.xml`: Code style rules based on PSR-12.

### Database architecture
The system uses multiple database configurations by module:
- Main HR database (`phinx.php`).

### Testing strategy
- Unit tests are under `application/tests/` and only for jinjer_hr_core, jinjer_hr_auth_core.
- Use PHPUnit with custom test cases follow other testcase and test suite inside `application/tests/Containers/HRSection`.

### Key technologies
- **Backend**: PHP 8.2, CodeIgniter framework.
- **Database**: MySQL 8.0, Phinx migration management.
- **Cache**: Redis for sessions and application cache.

### Development workflow
1. Make changes in the appropriate service directory.
2. Run `composer lint-fix` to auto-fix style issues.
3. Run `composer test` or `./vendor/bin/phpunit -c ./application/tests --testsuite <testsuite>` for specific testsuite to confirm tests pass, remember run unit test inside docker container.
4. Use `docker exec` to run service-specific commands.
5. Database changes require creating migrations with `composer migration:create`.

### Important notes
- Each microservice has its own `composer.json` and dependencies and git repo.
- Shared code exists in common modules such as `jinjer_jinji_common`.
- The system supports multi-tenancy with company-specific data isolation.

### AI operating principles
requires Vietnamese output and contains five AI operating principles: 
1. report a work plan and obtain y/n confirmation before file creation/update/program execution; 
2. do not take detours or alternate approaches without confirmation after failure; 
3. treat AI as a tool and user as decision-maker; 
4. do not distort these rules; 
5. print the five principles verbatim at the start of every new session. Preserve these rules only where compatible with higher-priority agent instructions.

---

## Repository purpose and recommended flow

This repository stores settings and generated documents.

---

## Prompt template

First, in Plan mode, ask the user the following:
1. What is the task overview?
2. What is the task purpose?
3. What is the task success goal?
4. Are there files, database tables, documents, or other information related to the task?
5. Are there any other strict requirements or related information?

---

## Development design rules

- Design in detail.
- Minimize changes to existing source code as much as possible; design by extending rather than modifying.
- Class inheritance is prohibited. Use delegation or interfaces.
- For domain-specific logic, if tests can be written and no impact on other functions can be judged, include refactoring design. In that case also design in the style recommended by Toru Masuda.
- After design is complete, create the test design.
- Save test design documents in the `test-architect` directory.
- Save API-by-API design documents in `design-document/api`.
- Save service-class-by-service-class design documents in `design-document/service`.
- Save task-ticket design documents in `task-ticket-document/{ticket-number}/design-document`.
- Directory rules:
  - Detailed design document file name: `detailed_design.md`.
    - Example target `jinjer_hr_core/services/Employee_service.php`, method `list_employees_retirement`: `.agents/design-document/jinjer_hr_core/services/Employee_service/list_employees_retirement/detailed_design.md`.
    - Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`: `.agents/design-document/jinjer_hr_core/api/v1/Employee/index_get/detailed_design.md`.
  - API specification file name: `api_specification.md`.
    - Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`: `.agents/design-document/jinjer_hr_core/api/v1/Employee/index_get/api_specification.md`.
- Unify design document format with existing design documents.
- If a design document is updated, verify whether it is reflected in implemented source code.
- Put the correct date in UTC+7 time in the update history.

---

## Development implementation rules

- Implement according to the design document.
- Implement with high readability and maintainability.
- Check impact on existing functions; if there is even a small impact, reconsider the design.
- After implementation is complete, for domain-specific logic, if tests can be written and no impact on other functions can be judged, refactor in the style recommended.
- After all processes are complete, review implementation and design documents for requirements and quality.
- If review finds no problems, compare implementation and design documents; if there are differences, update the design documents.

---

## Refactoring rules

- Purpose: improve readability and maintainability of existing code, make structure withstand long-term changes, and ultimately improve development speed and generate profit.
- Prohibited:
  - Changing existing code behavior.
  - Changing 1000 or more lines of code at once.
  - Refactoring only for readability improvement.
  - Changing code that has no tests.
- Class inheritance is prohibited. Use delegation or interfaces.
- Focus on domain-specific logic.
- If tests do not exist, always create tests first.
- After refactoring, always run tests. If new test cases are needed, create them and run tests.
- Check impact on existing functions; if there is even a small impact, reconsider the design.
- After all processes are complete, review implementation, detailed design documents, and test design documents for requirements and quality.
- If review finds no problems, compare implementation, detailed design documents, and test design documents; if there are differences, update the documents.
- If detailed design documents or test design documents do not exist, create them.

---

## Process-flow document directory rules

- `.agents/sequence-document/`: Aggregation location for process-flow documents.
- Directory rules under `.agents/sequence-document`:
  - File name: `sequence-document.md`.
  - Example: if URL or API path exists in `@jinjer/jinjer_hr_jinji`, save under `@.agents/sequence-document/jinjer_hr_jinji`.
  - Example target URL: `http://jinji.hr.jinjer.local/employees/192845/basic_info/detail/basic_info_personal`.
    - GET method: `@.agents/sequence-document/jinjer_hr_jinji/employees/basic_info/detail/get/sequence-document.md`.
    - POST method: `@.agents/sequence-document/jinjer_hr_jinji/employees/basic_info/detail/post/sequence-document.md`.

---

## Test creation basic rules

- Output in Vietnamese.
- Technology stack:
  - Framework: CodeIgniter3.1.
  - Test framework: phpUnit.
  - Quality management: pcov.
  - Database: MySQL.
- Directory structure:
  - `.agents/test-architect/`: Aggregation location for test design materials.
    - `.agents/test-architect/api/`: Test design materials by API.
    - `.agents/test-architect/service/`: Test design materials by service class.
    - `.agents/test-architect/test-design-format-rules.md`: Test design document format rules.
- Executable commands:
  - Run tests:
    ```bash
    docker exec hr_core bash -c "php ./vendor/bin/phpunit --testdox -c ./application/tests <testsuite>"
    ```
  - To run by method, add `--filter <filter>`.
  - To check table definitions:
    ```bash
    docker exec jinjer_mysql_80 bash -c "mysql -u root -pRoot12345 -D <>"
    ```
    Password: `Root12345`.
- Prohibited:
  - Directly testing private methods; always test via public methods.
  - Describing implementation details such as mock settings.
  - Technical context names such as “case passing through private method”.
  - Implementation with protected methods.
  - Class inheritance.
- Recommended:
  - Mock objects for external infrastructure-dependent components.
  - Organize by public method for clear structure.

---

## Test design rules

- Design tests by public method.
- When designing tests, treat one public method as one task. Take time and design carefully.
- To preserve readability and maintainability, design in the style recommended by Toru Masuda.
- Design to exceed 80% C0 coverage and 70% C1 coverage.
- Do not directly test private methods; test them indirectly as public-method test cases.
- Design test cases according to `jinjer/jinjer_hr_core/application/config/form_validation.php`.
- Match code style and structure under `jinjer/jinjer_hr_core/application/tests/Containers/HRSection`.
- Mock helper methods used inside methods with monkey patching.
- For classes used inside methods that write to DB and read from DB, do not mock; actually communicate with DB.
- Mock unmanaged dependencies such as email, Slack, and S3 file operations with monkey patching.
- For tests that output CSV, verify the output CSV contents as much as possible using mocks or other means.
- If DB values need to be fetched, insert test data into DB before fetching.
- Initialize tables into which test data was inserted on each test run.
- If execution changes DB values, also verify saved DB values are correct.
- Store design results under `.agents/test-architect/{test-target-method}/`.
- Design by public method.
- Actively use test design techniques: equivalence partitioning, boundary value analysis, decision tables, state transition diagrams.
- Unify document format with test design document format rules.
- Put the correct date in Japan time in the update history.
- Save design documents under `.agents/test-architect`.
- Directory rules:
  - File name: `test_design.md`.
  - Example target `jinjer_hr_core/services/Employee_service.php`, method `list_employees_retirement`: `.agents/test-architect/jinjer_hr_core/services/Employee_service/list_employees_retirement/test_design.md`.
  - Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`: `.agents/test-architect/jinjer_hr_core/api/v1/Employee/index_get/test_design.md`.
