# Active repo responsibility map

Active repos in `{{REPO_ROOT}}`:

- `jinjer_hr_auth` (`hr_auth`): SSO/auth app, login/authentication UI/API edge.
- `jinjer_hr_auth_core` (`hr_auth_core`): auth core services, SSO/OpenID/SAML core behavior.
- `jinjer_hr_core` (`hr_core`): shared/core HR backend APIs, employee/org/master/import/salary domains.
- `jinjer_hr_jinji` (`hr_jinji`): Jinji HR app, views/controllers/front-facing HR flows, calls to core/auth.

Ignored unless explicitly requested:
- `jinjer_hr_employee`
- `jinjer_hr_yeta`

Common domain hints:
- SSO/SAML/OpenID/OIDC/login/auth/認証/external service -> auth, auth_core, jinji.
- employee/affiliation/organization/department/role/permission/import/master/API -> core, jinji.
- UI/view/screen/form -> jinji.
- shared validation/model/service/API endpoint -> core or auth_core depending domain.
