# Testing reference

Use this reference for test design, test implementation, and validation work in the Jinjer PHP8 workspace.

Source rules:
- `.agents/rules/test-basic.md`
- `.agents/rules/test-design.md`
- `.agents/rules/test-implement.md`

## Scope

- User-facing output must be Vietnamese unless requested otherwise.
- Unit tests are under `application/tests/`.
- Unit testing is expected only for `jinjer_hr_core` and `jinjer_hr_auth_core`.
- Follow existing PHPUnit patterns, especially under `application/tests/Containers/HRSection` when working in `jinjer_hr_core`.
- Do not use Browser/manual QA on Jinji.
- Do not use Browser/CURL for testing unless the user explicitly allows it.
- Migration-only DB changes do not require migration DB tests.

## Test implementation rules

- Before implementing tests, run test DB initialization when needed:

```bash
docker exec hr_core bash -c "cd /usr/src/app && composer init_data_test"
```

- Run relevant tests during implementation:

```bash
docker exec hr_core bash -c "php ./vendor/bin/phpunit --testdox -c ./application/tests <testsuite> --filter <filter>"
```

- If no filter is needed, omit `--filter <filter>`.
- After implementation, run all implemented test cases and confirm execution.
- Review test implementation against requirements and the test design document.
- If implementation and design differ, update the test design document.

## Mocking and DB strategy

Mock or monkey patch:
- Helper methods used inside target methods.
- External infrastructure dependencies such as email, Slack, S3, and external APIs.

Do not mock:
- Classes that write to DB.
- Classes that read from DB.
- DB operations that are central to the behavior under test.

DB tests:
- Insert required test data before fetching it.
- Initialize or clean affected tables on each test run.
- If execution changes DB values, verify saved DB values.
- Use realistic and meaningful test data.

CSV output:
- Verify output CSV contents as much as possible.
- Capture output with mocks or other appropriate test utilities.

## Coverage workflow

When adding tests for existing uncovered behavior:

1. Check the current coverage report at `application/tests/build/coverage/html/index.html`.
2. Record target method line numbers and current line/branch coverage status.
3. Implement and run the tests.
4. Re-check the coverage report.
5. Confirm both line and branch coverage improved or document why remaining paths are not covered.

## Prohibited practices

- Directly testing private methods.
- Describing mock settings or implementation details in test design.
- Using technical context names instead of business-meaningful case names.
- Adding protected methods for testability.
- Introducing class inheritance.
