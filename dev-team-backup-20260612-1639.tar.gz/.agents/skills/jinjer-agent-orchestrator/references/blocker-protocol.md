# Codex worker blocker protocol

When blocked, workers must not guess. They must write:

`{{REPO_ROOT}}/.agents/runs/<TASK>/<repo>/blocker.md`

Required format:

```markdown
# Blocker: <TASK> <repo>

## Need human answer
<one direct question>

## Context
<short facts discovered>

## Options
1. <option A + tradeoff>
2. <option B + tradeoff>

## Recommended option
<option + reason>

## Safe next command after answer
<command or rerun instruction>
```

Also create marker file:
`{{REPO_ROOT}}/.agents/runs/<TASK>/<repo>/needs-human`

Final result must mention blocker path.
