# MCP / external context integration

Use these integrations when clearing Jira specs, Confluence docs, Bitbucket PRs, or repo impact before implementation.

## Safety
- Never print tokens/passwords from config files.
- External writes require explicit user request: Jira transitions/comments, Confluence edits, Bitbucket comments/approvals.
- Reads are allowed for task context.
- If auth fails, report blocker and exact non-secret command checked.

## Bitbucket MCP

Primary Bitbucket MCP is project-local through `.mcp.json`.
Local server: `{{REPO_ROOT}}/.dev-team/agents/bitbucket/server.js`.
Auth: `{{REPO_ROOT}}/.dev-team/agents/bitbucket/.env` — do not print.

Current `.mcp.json` entry:

```json
"bitbucket": {
  "command": "node",
  "args": [
    "{{REPO_ROOT}}/.dev-team/agents/bitbucket/server.js"
  ]
}
```

Useful MCP tools exposed to Codex:

```text
parse_pr_url
get_pullrequest
get_diff
get_diffstat
add_comment
approve
```

Use reads freely for task context. Ask before Bitbucket writes such as comments or approvals.

## Confluence

No dedicated Confluence MCP registered yet. Use Confluence REST API with Jira credentials from `.dev-team/agents/jira/.env`.
Never print API token.

Base: `https://jinjer-co-ltd.atlassian.net/wiki`.

Common reads:

```bash
# Search
curl -sS -u "$JIRA_EMAIL:$JIRA_TOKEN" \
  'https://jinjer-co-ltd.atlassian.net/wiki/rest/api/search?cql=siteSearch%20~%20"SSO"&limit=25&expand=content.space,content.version'

# Get page storage body
curl -sS -u "$JIRA_EMAIL:$JIRA_TOKEN" \
  'https://jinjer-co-ltd.atlassian.net/wiki/api/v2/pages/<PAGE_ID>?body-format=storage'
```

Prefer creating local task notes under `.dev-team/task-flows/<FLOW_ID>/context.md` instead of editing Confluence unless user explicitly requests.

## Context gathering flow

1. Read Jira issue and comments.
2. Search Confluence with ticket key, feature name, domain terms.
3. If Bitbucket PR URL/branch exists, fetch PR metadata + diffstat.
4. Summarize into `.dev-team/task-flows/<FLOW_ID>/context.md`:
   - business goal
   - affected repos/files
   - API/data changes
   - open questions
   - implementation/test plan
5. Feed summary to Codex workers through dev-team prompt flow.
