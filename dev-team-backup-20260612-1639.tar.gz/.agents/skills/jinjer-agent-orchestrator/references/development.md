# Development reference

Use this reference for design, implementation, and refactoring work in the Jinjer PHP8 workspace.

Source rules:
- `.agents/rules/development-basic.md`
- `.agents/rules/development-design.md`
- `.agents/rules/development-implement.md`
- `.agents/rules/development-refactor.md`
- `.agents/rules/pr-precheck.md`

## Scope and repo handling

- Confirm the target repo and task before editing.
- If the target repo is unclear, read `references/repo-map.md`.
- Each service is a separate repository with its own dependencies and git history.
- Do not treat the PHP8 root directory as a service working directory.
- Check git status in the target repo or scoped target paths before editing.
- Never overwrite user/local changes. If local changes affect the task, work with them or report a blocker.
- Keep changes minimal and testable.

## Development workflow

1. Identify the target service, affected files, and relevant design/test documents.
2. Read the existing implementation and local patterns before deciding changes.
3. Assess impact on existing functions. If there is even a small impact, reconsider the design.
4. Implement according to the detailed design document when one exists.
5. Keep code readable and maintainable, following the service's existing conventions.
6. Validate with Docker-based commands when possible.
7. Review implementation against requirements, design documents, and test design documents.
8. If implementation differs from documents, update the relevant documents.
9. Report changed files, checks, blockers, and the next step.

## Implementation rules

- Implement according to the design document.
- Maintain project naming, Japanese/Vietnamese business terms, and local CodeIgniter/PHP patterns.
- Add comments only for complex logic that would otherwise be hard to follow.
- Do not introduce class inheritance.
- Do not make unrelated refactors.
- If review finds design and implementation differences, update the documents.

Common service commands:

```bash
composer lint-fix
composer test
./vendor/bin/phpunit -c ./application/tests --testsuite <testsuite>
```

Run service commands inside the appropriate Docker container when possible.

## Refactoring rules

Refactoring is allowed only when it improves long-term structure and maintainability without behavior changes.

Prohibited:
- Changing existing behavior.
- Changing 1000 or more lines at once.
- Refactoring only for cosmetic readability.
- Refactoring code that has no tests.
- Introducing class inheritance.

Required:
- Create or confirm tests before refactoring.
- Focus on domain-specific logic.
- Make incremental, verifiable changes.
- Run the relevant tests after refactoring.
- Review and update detailed design and test design documents if needed.

## Blockers

If business behavior, ownership, or impact cannot be determined safely, do not guess. Follow `references/blocker-protocol.md`.
