---
name: jinjer-agent-orchestrator
description: Jinjer PHP8 Codex workflows for implementation, repo detection, Docker validation, testing, PR pre-checks, design docs, ticket/spec handling, and blocker reporting.
---

# Jinjer PHP8 Workflows

Use this skill for engineering work in `{{REPO_ROOT}}`.

## Five principles

1. Confirm target repo and task before editing.
2. Check git status first; never overwrite local changes.
3. Keep changes minimal and testable.
4. Validate in Docker/worktree helpers when possible.
5. Report changed files, checks, blockers, next step.

## Active repos

Read `references/repo-map.md` when target repo is unclear.

Active:
- `jinjer_hr_auth`
- `jinjer_hr_auth_core`
- `jinjer_hr_core`
- `jinjer_hr_jinji`

Ignored unless explicit:
- `jinjer_hr_employee`
- `jinjer_hr_yeta`

## Reference selection

- Development/design/implementation/refactor: `references/development.md`
- Test design/implementation/validation: `references/testing.md`
- Repo ownership/detection: `references/repo-map.md`
- Blocked worker protocol: `references/blocker-protocol.md`
- MCP/external context: `references/mcp.md`

## Rules

- Use Vietnamese for user-facing final summaries unless user asks otherwise.
- Preserve project Japanese/Vietnamese business terms.
- Do not print secrets.
- Ask before destructive git operations or external writes.
- If business behavior is unclear, create/report blocker instead of guessing.
