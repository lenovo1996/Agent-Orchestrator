# `jinjer_hr_authentication` another name is `jinjer_hr_auth_core`

`jinjer_hr_authentication` is the specialized authentication foundation/core service for Jinjer HR. It implements OpenID Connect authentication protocol, company-specific authentication settings, MFA, and external authentication provider integration. While `jinjer_hr_auth` handles SSO and session management, this service handles low-level authentication primitives and advanced security features.

Main responsibilities:
- OpenID Connect authentication foundation using the `hr/openidconnect` package.
- OAuth 2.0 / OpenID Connect compliant flows, including Authorization Code Flow and PKCE.
- Advanced authentication and MFA: TOTP, SMS, email authentication, code generation/verification/resend/session management, bounce detection, device management, backup codes.
- Company-specific authentication settings and integration, including policies, external providers such as Docomo, custom flows, and legacy integration.
- Public API authentication for external systems, JWT issuance/verification, API authentication, and session verification.

Technology:
- CodeIgniter on PHP 8.2+.
- Firebase PHP-JWT.
- Custom OpenID Connect implementation through `hr/openidconnect`.
- Illuminate Database / Laravel Eloquent.
- Guzzle HTTP.
- AWS SDK PHP.
- Luthier routing.

Role split with `jinjer_hr_auth`:
- `jinjer_hr_auth`: SAML 2.0 SSO, session management, unified login UX, frontend authentication, single sign-on/logout.
- `jinjer_hr_authentication`: OpenID Connect foundation, company-specific auth logic, advanced security such as MFA, backend authentication infrastructure, protocol processing, security policy implementation.

Typical flow:
1. `jinjer_hr_auth` receives an SSO authentication request.
2. `jinjer_hr_authentication` performs OpenID Connect processing.
3. Company-specific authentication policy is applied.
4. MFA Challenge is performed if needed.
5. `jinjer_hr_core` retrieves user information.
6. `jinjer_hr_auth` creates and manages the session.
7. Authentication result returns to frontend services.

Main APIs:
- `/api/v1/auth`: basic auth, session verification, password policy, Docomo/external callbacks, IP restriction verification.
- `/api/v1/mfa`: resend, verify, check-bounce, check-mfa-session.

---