# `jinjer_jinji_common`

`jinjer_jinji_common` is the shared common module library for the HR administrator interface `jinjer_hr_jinji`. It provides common API clients, helpers, services, UI parts, layouts, and role/menu control for administrator-facing HR functions.

Main responsibilities:
- Administrator-side API integration platform.
- Shared UI components for HR management screens.
- Role, menu, and permission control for administrators.
- Common utilities for HR administrator workflows.
- Support for complex HR business operations and high-volume API usage.

Relationships:
- Used by `jinjer_hr_jinji` as a common module.
- Calls `jinjer_hr_core` through many API clients.
- Participates in the simple 3-layer flow or authentication-integrated 5-layer flow depending on environment and security requirements.

---