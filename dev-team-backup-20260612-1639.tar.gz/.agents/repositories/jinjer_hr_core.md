# `jinjer_hr_core`

`jinjer_hr_core` is the central API server and business logic repository for Jinjer HR. It provides RESTful APIs for HR management and functions as a multi-module platform integrating specialized modules such as payroll, electronic contracts, expenses, invoices, and My Number management.

Main responsibilities:
- Core APIs and business logic for HR operations.
- Employee, organization, department, contract, approval, payroll, evaluation, audit, and log data handling.
- Central data access to `jinjer_core(DB)`.
- API provider for frontend services and shared modules.
- Integration point for authentication services and business modules.

Typical position:

```text
Frontend / Common modules / Auth services → jinjer_hr_core → jinjer_core(DB)
```

Use `jinjer_hr_core` as source of truth for business data and business rules. Frontend services and common modules should call it through API clients rather than duplicating core business logic.

---