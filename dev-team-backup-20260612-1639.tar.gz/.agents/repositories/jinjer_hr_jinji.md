# `jinjer_hr_jinji`

`jinjer_hr_jinji` is the HR administration interface for HR managers and administrators. It provides management screens and workflows for employee administration, organization settings, onboarding/import, reports, approvals, and HR operations.

Main responsibilities:
- HR administrator UI.
- Employee management and HR operation screens.
- Large-volume data operations such as batch and reports.
- Complex business workflows and multi-step approvals.
- Administrator permissions and audit-oriented operations.

Relationships:
- Uses `jinjer_jinji_common` for administrator-facing common clients, helpers, UI components, and shared logic.
- Communicates heavily with `jinjer_hr_core` through API clients.
- Uses `jinjer_hr_auth` and `jinjer_hr_authentication` for SSO/authentication when required.

Communication characteristics:
- Many API clients.
- High-frequency and large-volume API use.
- Desktop-optimized, large-screen, multifunction UI.

---