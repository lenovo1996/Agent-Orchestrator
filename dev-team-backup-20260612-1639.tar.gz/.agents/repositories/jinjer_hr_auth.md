# `jinjer_hr_auth`

`jinjer_hr_auth` is the authentication and authorization service for Jinjer HR. It provides SAML 2.0-based SSO, integrates with external IdPs such as Google Workspace, supports JWT token authentication and MFA, and acts as the unified authentication foundation for frontend services.

Main responsibilities:
- SSO authentication service using SAML 2.0.
- External IdP integration such as Google Workspace and Azure AD.
- Single sign-on and single logout.
- Centralized session lifecycle management.
- RESTful authentication API at `/api/v1/auth`.
- JWT issuance and verification.
- Redis-based distributed sessions.
- Role-based access control foundation.
- MFA Challenge and risk-based authentication.

Technology:
- CodeIgniter on PHP 8.2+.
- SimpleSAMLphp 2.2.2.
- Firebase PHP-JWT.
- Guzzle HTTP.
- Redis + Predis.
- AWS SDK PHP.

Architecture:
- Authentication layer: `SsoController`, Auth API Controller, MFA Challenge Controller, Session Manager.
- Service layer: `Auth_service`, `Identity_provider_service`, `SessionCheckService`, `MfaChallenge`.
- Integration layer: `jinjer_hr_core` API client, Redis session storage, external IdP connector, AWS integration.

Main flows:
- SSO: user → `jinjer_hr_auth` → external IdP → `jinjer_hr_core` → JWT/session → application.
- API authentication: client posts credentials to `/api/v1/auth`; service validates via `jinjer_hr_core`; JWT and Redis session are created.
- Token verification: `/api/v1/auth/check` verifies JWT signature, expiration, issuer, Redis session, and user status.

Repository relationships:
- Provides admin login, role-based access control, sessions, SSO, and security policy application to `jinjer_hr_jinji`.
- Provides employee authentication, self-service access control, My Page sessions, application/approval permissions, and privacy protection to `jinjer_hr_employee`.
- Also supports document management and other frontend services through unified authentication.

---