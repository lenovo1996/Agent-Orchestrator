## From `review/general_code_review_guide.md`: General code review guideline

### Purpose and principles
Code review maintains and improves code and product quality by improving codebase health, finding bugs early, sharing knowledge, keeping consistency, and improving maintainability/readability.

Principles:
- Value continuous improvement over perfection. Approve CLs/PRs that improve system health; do not approve CLs that worsen health except in emergencies.
- Code is communication with other developers and future self; write clear, understandable code.
- Comment respectfully on code, not the developer. Explain why.
- Respond quickly to review requests, ideally within one business day, without interrupting focused work unnecessarily.
- Distinguish objective good/bad feedback from subjective preference and explain reasons.

### Design review viewpoints
- Apply SRP: each class/method should have one clear responsibility.
- Favor high cohesion and low coupling.
- Avoid unnecessary value objects and excessive generalization that violates YAGNI.
- Place business logic and data access logic in appropriate classes.
- Prefer composition/delegation over inheritance.
- Localize impact of changes.
- Keep data and logic that operates on it together.
- Separate concerns such as UI, business logic, and data access.
- Depend on interfaces/abstractions rather than concrete classes where useful.
- Design for reuse through modules, components, and configuration.
- Identify likely future change points and isolate them.
- Follow OCP where appropriate.
- Keep code simple (KISS) and avoid overengineering (YAGNI).
- Use standard methods when possible.
- Design Web APIs RESTfully; choose URLs and HTTP methods appropriately.
- Keep API/method interfaces consistent.
- Ensure parameters are necessary and sufficient; do not expose client-sent internal IDs unnecessarily.
- Use interoperable standards such as JSON and REST.
- Keep abstraction levels consistent (SLAP); extract lower-level details.
- Abstract duplicate logic into classes/methods.
- Ensure abstractions have proper sufficiency, completeness, and primitiveness.
- Use framework features appropriately.
- Avoid unnecessary dependencies and reinventing wheels.

Design review is mandatory by senior engineer or above for PRs involving designs hard to change later, integrations with external products, database additions/changes, or new model-related classes. For external product integrations, include the product owner in design review.

### Code quality viewpoints
- Code should be readable and intent should be clear even to first-time readers.
- Diffs should be easy to follow with appropriate granularity.
- Control flow should be simple; reduce deep nesting with guard clauses, early returns, method extraction, or polymorphism.
- Statements should be in logical order and grouped with whitespace.
- Treat code as the most reliable design document.
- Processing flow should read naturally from top to bottom.
- Logic should be self-evident; document complex parts.
- Names should be clear, specific, consistent, convention-compliant, pronounceable, searchable, and match behavior.
- Names should show side effects and communicate both effect and purpose.
- Avoid duplicate logic, settings, and constants.
- Avoid unnecessary complexity and premature optimization.
- Replace meaningful magic numbers/strings with named constants.
- Remove unused code, dead code, and commented-out obsolete code.
- Comments should explain why/intent, not obvious how. Keep comments accurate and up to date. Use TODO/FIXME per team rules.
- Follow style guides consistently; nitpicks should be labeled such as `Nit:` and not forced if pure preference.
- Handle errors, unexpected input, transactions, resources, and logs correctly.
- Use defensive programming: assertions, input validation, consistent error strategy, and safe handling of unlikely edge cases.
- Choose appropriate data types, booleans, enums, and data structures.
- Consider performance: algorithms, DB N+1, fetching unnecessary data, DB-side processing, indexes, memory use, and failure tolerance.
- Prefer immutability and referential transparency when possible.

### Test review viewpoints
- Use appropriate test levels: unit, integration, system/E2E.
- Code should be testable via dependency injection and side-effect separation.
- Cover normal, abnormal, and boundary cases.
- Test cases should be concrete, independent, stable, and have accurate assertions.
- Test code should use Arrange/Act/Assert structure.
- Expected values should be clear from test code itself.
- Balance DRY with test independence/readability.
- Do not write redundant tests of framework/library standard features.
- Avoid UI design dependencies in system tests; prefer test attributes.
- Use mocks/stubs appropriately for external dependencies, without over-mocking.
- Prepare test data in a way that clarifies test intent.

### Documentation and process viewpoints
- Clarify code intent with comments where code alone is insufficient.
- Update related documentation such as README, API specs, and design documents with code changes.
- Request documentation creation when necessary documentation is missing.

---
