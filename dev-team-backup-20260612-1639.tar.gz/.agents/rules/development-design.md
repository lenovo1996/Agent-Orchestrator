# Development Design Rules

## Core Principles

- Design in detail
- Minimize changes to existing source code as much as possible; design by extending rather than modifying
- Class inheritance is prohibited. Use delegation or interfaces
- For domain-specific logic, if tests can be written and no impact on other functions can be judged, include refactoring design. In that case also design in the style recommended by Toru Masuda
- After design is complete, create the test design

## Design Document Storage

### Test Design Documents

- Save test design documents in the `test-architect` directory

### API Design Documents

- Save API-by-API design documents in `design-document/api`

### Service Design Documents

- Save service-class-by-service-class design documents in `design-document/service`

### Task Ticket Design Documents

- Save task-ticket design documents in `task-ticket-document/{ticket-number}/design-document`

## Directory Rules

### Detailed Design Document

- File name: `detailed_design.md`
- Example target `jinjer_hr_core/services/Employee_service.php`, method `list_employees_retirement`:
  - Path: `.agents/design-document/jinjer_hr_core/services/Employee_service/list_employees_retirement/detailed_design.md`
- Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`:
  - Path: `.agents/design-document/jinjer_hr_core/api/v1/Employee/index_get/detailed_design.md`

### API Specification Document

- File name: `api_specification.md`
- Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`:
  - Path: `.agents/design-document/jinjer_hr_core/api/v1/Employee/index_get/api_specification.md`

## Document Format and Quality

- Unify design document format with existing design documents
- If a design document is updated, verify whether it is reflected in implemented source code
- Put the correct date in UTC+7 time in the update history

## Design Verification

After design is complete:

1. Create the test design
2. Verify design document completeness
3. Check consistency with existing patterns
4. Confirm no impact on existing functions
