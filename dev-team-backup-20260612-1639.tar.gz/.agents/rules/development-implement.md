# Development Implementation Rules

## Core Principles

- Implement according to the design document
- Implement with high readability and maintainability
- Check impact on existing functions; if there is even a small impact, reconsider the design
- After implementation is complete, for domain-specific logic, if tests can be written and no impact on other functions can be judged, refactor in the style recommended
- After all processes are complete, review implementation and design documents for requirements and quality

## Implementation Process

1. **Read and understand the design document**
   - Verify all requirements are clear
   - Identify dependencies and affected areas
   - Confirm test design exists

2. **Implement according to design**
   - Follow the detailed design document exactly
   - Maintain code readability and maintainability
   - Use appropriate naming conventions
   - Add necessary comments for complex logic

3. **Impact assessment**
   - Check impact on existing functions
   - If there is even a small impact, reconsider the design
   - Verify no unintended side effects

4. **Refactoring (when applicable)**
   - For domain-specific logic only
   - Only if tests can be written
   - Only if no impact on other functions can be judged
   - Follow recommended refactoring style

5. **Review process**
   - Review implementation against requirements
   - Review implementation against design documents
   - Check code quality
   - Verify test coverage

6. **Document synchronization**
   - Compare implementation and design documents
   - If there are differences, update the design documents
   - Ensure all changes are documented

## Quality Checks

Before considering implementation complete:

- [ ] Implementation matches design document
- [ ] Code is readable and maintainable
- [ ] No negative impact on existing functions
- [ ] Tests are written and passing
- [ ] Code follows project conventions
- [ ] Design documents are updated if needed
- [ ] All requirements are satisfied
