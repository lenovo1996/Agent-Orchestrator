# Development Basic Rules

## AI Operating Principles

This system requires Vietnamese output and contains five AI operating principles:

1. Report a work plan and obtain y/n confirmation before file creation/update/program execution
2. Do not take detours or alternate approaches without confirmation after failure
3. Treat AI as a tool and user as decision-maker
4. Do not distort these rules
5. Print the five principles verbatim at the start of every new session

**Note**: Preserve these rules only where compatible with higher-priority agent instructions.

## Repository Purpose and Recommended Flow

This repository stores settings and generated documents.

## Prompt Template

First, in Plan mode, ask the user the following:

1. What is the task overview?
2. What is the task purpose?
3. What is the task success goal?
4. Are there files, database tables, documents, or other information related to the task?
5. Are there any other strict requirements or related information?

## Common Development Commands

### Service Management

```bash
# Start all services
cd <current path>/../jinjer_hr_docker && docker-compose up -d

# Install dependencies inside service
docker exec hr_core bash -c "composer install"

# Access service shell
docker exec -it hr_core bash
```

### Database Migrations

```bash
# Run migrations
composer migrate

# Create new migration
composer migration:create {table_name}
```

### Code Quality and Testing

```bash
# Run full lint fix
composer lint-fix

# Run full test suite with coverage
composer test

# Run specific test suite
./vendor/bin/phpunit -c ./application/tests --testsuite <testsuite>
```

## Project Structure

- `application/`: Main MVC application code
  - `controllers/`: API and web controllers
  - `models/`: Database models using Eloquent ORM
  - `services/`: Business logic services
  - `jobs/`: Background job classes
  - `middleware/`: Authentication and authorization middleware
  - `routes/`: Route definitions
  - `validations/`: Input validation classes
- `database/`: Migration files and seeds
- `packages/`: Custom packages for electronic contracts and HR modules
- `assets/`: Static assets for each module

## Configuration Files

- `composer.json`: Dependencies and scripts
- `phinx.php`: Database migration settings
- `ruleset.xml`: Code style rules based on PSR-12

## Key Technologies

- **Backend**: PHP 8.2, CodeIgniter framework
- **Database**: MySQL 8.0, Phinx migration management
- **Cache**: Redis for sessions and application cache

## Development Workflow

1. Make changes in the appropriate service directory
2. Run `composer lint-fix` to auto-fix style issues
3. Run `composer test` or `./vendor/bin/phpunit -c ./application/tests --testsuite <testsuite>` for specific testsuite to confirm tests pass
4. Remember to run unit tests inside docker container
5. Use `docker exec` to run service-specific commands
6. Database changes require creating migrations with `composer migration:create`

## Important Notes

- Each microservice has its own `composer.json` and dependencies and git repo
- Shared code exists in common modules such as `jinjer_jinji_common`
- The system supports multi-tenancy with company-specific data isolation
