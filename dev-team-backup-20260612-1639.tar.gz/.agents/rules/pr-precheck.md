## PR task pre-check rules

Evaluate code and show results in a markdown table. After the table, show improvement suggestions for rows with result `×` or `△`.

Table columns: `Viewpoint`, `Result (⚪︎, ×, △, -)`, `Finding`.

Result criteria:
- `⚪︎`: No problem.
- `△`: No problem, but applying the finding is recommended.
- `×`: Must fix.
- `-`: Cannot evaluate / unrelated to this change.

Review viewpoints:
1. `lint-fix` already executed: confirm changed code has been formatted by `composer lint-fix`.
2. Commit messages and title checked against naming rules:
   - Get the Jira ticket from `JH-xxxx` in `$ARGUMENTS` and confirm there is no mismatch with changes.
   - Confirm commit messages are related to changes.
3. Security checked: SQL injection, XSS, etc.
   - Confirm changed code considers SQL injection, XSS, etc.
   - If unrelated, judge no problem.
4. try/catch implementation and variable-existence checks done:
   - If try/catch is necessary in changed code, confirm it is correctly implemented.
   - Confirm changed code does not use nonexistent variables.
5. Debug code removed if present.
6. Correct DB connection selected during data retrieval:
   - If changed code performs DB connection, confirm it connects to correct DB.
   - If unrelated, judge no problem.
7. Query performance verified, including indexes:
   - If queries changed, confirm no adverse performance impact.
   - If unrelated, judge no problem.
8. DB queries inside loops avoided:
   - Confirm changed code does not issue DB queries inside loops.
   - If changed area is existing code and existing code already issues DB queries inside loops, judge no problem.
9. EVD written and ticket status updated:
   - Get Jira ticket from `JH-xxxx` in `$ARGUMENTS` and confirm ticket status is not `オープン`.
   - First check authentication for mcp-atlassian-remote; authenticate if expired.
10. NULL checks done:
   - Confirm changed code has no places that error by null reference.
   - This item frequently causes bugs; check carefully.

---
