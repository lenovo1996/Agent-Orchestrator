# Test Creation Basic Rules

## Output Language

- Output in Vietnamese

## Technology Stack

- **Framework**: CodeIgniter 3.1
- **Test framework**: PHPUnit
- **Quality management**: pcov
- **Database**: MySQL

## Executable Commands

### Run Tests

```bash
docker exec hr_core bash -c "php ./vendor/bin/phpunit --testdox -c ./application/tests <testsuite> --filter <filter>"
```

- To run by method, add `--filter <filter>`

### Check Table Definitions

```bash
docker exec jinjer_mysql bash -c "mysql -u root -pRoot12345 -D <database_name>"
```

- Password: `Root12345`

## Prohibited Practices

1. **Directly testing private methods**
   - Always test via public methods
   - Private methods are tested indirectly through public method test cases

2. **Describing implementation details**
   - Do not describe mock settings in test design
   - Focus on behavior, not implementation

3. **Technical context names**
   - Avoid names like "case passing through private method"
   - Use business-meaningful test case names

4. **Implementation with protected methods**
   - Keep methods public or private
   - Avoid protected methods in test subjects

5. **Class inheritance**
   - Use composition and delegation instead
   - Follow project-wide inheritance prohibition

## Recommended Practices

1. **Mock objects for external infrastructure-dependent components**
   - Mock email services
   - Mock Slack notifications
   - Mock S3 file operations
   - Mock external APIs

2. **Organize by public method**
   - One test class per public method or logical grouping
   - Clear structure for maintainability

3. **Use monkey patching for helper methods**
   - Mock helper methods used inside methods
   - Preserve test isolation

4. **Actual DB communication for DB operations**
   - For classes that write to DB and read from DB, do not mock
   - Actually communicate with DB for realistic testing
   - Initialize tables on each test run

5. **Verify DB values after changes**
   - If execution changes DB values, verify saved DB values are correct
   - Ensure data integrity

## Test Data Management

1. **Insert test data before fetching**
   - If DB values need to be fetched, insert test data into DB first
   - Use realistic test data

2. **Initialize tables on each test run**
   - Clean up test data after each test
   - Ensure test isolation and repeatability

3. **CSV output verification**
   - For tests that output CSV, verify the output CSV contents as much as possible
   - Use mocks or other means to capture and verify output

## Testing Strategy

- Unit tests are under `application/tests/` and only for `jinjer_hr_core`, `jinjer_hr_auth_core`
- Use PHPUnit with custom test cases following other testcases and test suites inside `application/tests/Containers/HRSection`
- Match code style and structure under `jinjer/jinjer_hr_core/application/tests/Containers/HRSection`
- REMEMBER only Unit test for testing. dont use Browser/CURL if user not allow.
- REMEMBER no need testing for migration Db test.
