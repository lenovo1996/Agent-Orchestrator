# Test Design Rules

## Core Principles

- Design tests by public method
- When designing tests, treat one public method as one task. Take time and design carefully
- To preserve readability and maintainability, design in the style recommended by Toru Masuda
- Design to exceed 80% C0 coverage and 70% C1 coverage
- Do not directly test private methods; test them indirectly as public-method test cases

## Test Design Process

1. **Analyze the target method**
   - Understand method purpose and behavior
   - Identify all execution paths
   - Map dependencies and external calls

2. **Apply test design techniques**
   - Equivalence partitioning
   - Boundary value analysis
   - Decision tables
   - State transition diagrams (for complex state-dependent logic)

3. **Design test cases**
   - Normal cases
   - Abnormal cases
   - Edge cases
   - Boundary cases
   - Validation cases

4. **Plan mocking strategy**
   - Mock helper methods with monkey patching
   - Do not mock DB operations (use actual DB)
   - Mock unmanaged dependencies (email, Slack, S3)

5. **Document the design**
   - Follow test design format rules
   - Store under `.agents/test-architect/{test-target-method}/`
   - Use consistent naming and structure

## Validation Rules

- Design test cases according to `jinjer/jinjer_hr_core/application/config/form_validation.php`
- Cover all validation rules defined in the configuration
- Test both valid and invalid inputs for each validation rule

## Code Style and Structure

- Match code style and structure under `jinjer/jinjer_hr_core/application/tests/Containers/HRSection`
- Follow existing test patterns and conventions
- Use consistent naming for test methods and test data

## Mocking Strategy

### Mock with Monkey Patching

- Helper methods used inside methods
- Unmanaged external dependencies:
  - Email services
  - Slack notifications
  - S3 file operations

### Do Not Mock (Use Actual DB)

- Classes that write to DB
- Classes that read from DB
- Database operations should use actual database for realistic testing

### CSV Output Verification

- For tests that output CSV, verify the output CSV contents as much as possible
- Use mocks or other means to capture and verify CSV data

## Database Testing

### Test Data Management

1. **Insert test data before fetching**
   - If DB values need to be fetched, insert test data into DB before fetching
   - Use realistic and meaningful test data

2. **Initialize tables on each test run**
   - Clean up tables into which test data was inserted
   - Ensure test isolation and repeatability

3. **Verify DB changes**
   - If execution changes DB values, also verify saved DB values are correct
   - Check data integrity and consistency

## Coverage Targets

- **C0 (Line Coverage)**: 80% or more
- **C1 (Branch Coverage)**: 70% or more
- Focus on important execution paths
- Ensure all critical business logic is covered

## Document Storage

### Directory Rules

- File name: `test_design.md`
- Example target `jinjer_hr_core/services/Employee_service.php`, method `list_employees_retirement`:
  - Path: `.agents/test-architect/jinjer_hr_core/services/Employee_service/list_employees_retirement/test_design.md`
- Example target `jinjer_hr_core/application/controllers/v1/Employee.php`, method `index_get`:
  - Path: `.agents/test-architect/jinjer_hr_core/api/v1/Employee/index_get/test_design.md`

## Document Format

- Unify document format with test design document format rules
- Put the correct date in Japan time (UTC+9) in the update history
- Follow the standard structure defined in `formats/test-design.md`

## Quality Checklist

Before considering test design complete:

- [ ] All public methods have test cases
- [ ] Test design techniques applied (equivalence partitioning, boundary value analysis, decision tables)
- [ ] Coverage targets are achievable (80% C0, 70% C1)
- [ ] Mocking strategy is clear and appropriate
- [ ] Test data management is planned
- [ ] DB initialization strategy is defined
- [ ] CSV output verification is planned (if applicable)
- [ ] Document follows format rules
- [ ] Design is implementable
- [ ] Consistency with existing test patterns verified
