# Refactoring Rules

## Purpose

Improve readability and maintainability of existing code, make structure withstand long-term changes, and ultimately improve development speed and generate profit.

## Prohibited Actions

1. **Changing existing code behavior**
   - Refactoring must preserve existing functionality
   - Any behavior change requires separate design and approval

2. **Changing 1000 or more lines of code at once**
   - Keep refactoring incremental and manageable
   - Break large refactorings into smaller, reviewable chunks

3. **Refactoring only for readability improvement**
   - Readability improvements must be combined with structural improvements
   - Pure cosmetic changes are not sufficient justification

4. **Changing code that has no tests**
   - Always create tests first before refactoring
   - Tests serve as safety net for refactoring

5. **Class inheritance**
   - Use delegation or interfaces instead
   - Favor composition over inheritance

## Required Practices

### Before Refactoring

1. **Ensure tests exist**
   - If tests do not exist, always create tests first
   - Tests must cover the code being refactored
   - Verify tests pass before starting refactoring

2. **Focus on domain-specific logic**
   - Prioritize business logic refactoring
   - Infrastructure code refactoring requires additional justification

3. **Impact assessment**
   - Check impact on existing functions
   - If there is even a small impact, reconsider the design
   - Document all potential impacts

### During Refactoring

1. **Follow design principles**
   - Use delegation or interfaces (no class inheritance)
   - Apply appropriate design patterns
   - Maintain separation of concerns

2. **Incremental changes**
   - Make small, verifiable changes
   - Run tests after each change
   - Commit frequently with clear messages

3. **Maintain behavior**
   - Verify tests continue to pass
   - Check for any behavior changes
   - Document any necessary behavior adjustments

### After Refactoring

1. **Run all tests**
   - Execute full test suite
   - If new test cases are needed, create them and run tests
   - Verify coverage has not decreased

2. **Impact verification**
   - Check impact on existing functions
   - Verify no unintended side effects
   - Test integration points

3. **Documentation review**
   - Review implementation against requirements
   - Review detailed design documents
   - Review test design documents
   - Update documents if differences exist

4. **Create missing documentation**
   - If detailed design documents do not exist, create them
   - If test design documents do not exist, create them
   - Ensure all refactored code is properly documented

## Quality Checklist

Before considering refactoring complete:

- [ ] Tests existed before refactoring or were created first
- [ ] All tests pass
- [ ] No behavior changes occurred
- [ ] Less than 1000 lines changed
- [ ] No class inheritance introduced
- [ ] Impact on existing functions verified
- [ ] Design documents reviewed and updated
- [ ] Test design documents reviewed and updated
- [ ] Code quality improved
- [ ] Maintainability improved
