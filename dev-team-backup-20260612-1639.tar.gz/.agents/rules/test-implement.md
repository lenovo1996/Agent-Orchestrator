## Test implementation rules

- As developer, implement test cases based on design documents created by the architect.
- Architect designs comprehensively and correctly from a test-design perspective, but some cases may be redundant in implementation. Select only necessary cases as appropriate.
- During test implementation, treat one public method as one task. Take time and implement carefully.
- Before test implementation, run migrations on test DB to bring DB up to date:
  ```bash
  docker exec hr_core bash -c "cd /usr/src/app && composer init_data_test"
  ```
- Check coverage as follows:
  1. Before implementing tests, load `jinjer_hr_core/application/tests/build/coverage/html/index.html`, record target method line numbers and coverage status, and understand pre-implementation coverage.
  2. Implement tests.
  3. After implementing tests, load `jinjer_hr_core/application/tests/build/coverage/html/index.html`, check target method line numbers and coverage status, and compare with step 1. This shows whether implementation improved coverage and whether uncovered execution paths remain.
- Check both Line and Branch coverage.
- Debug frequently as each test case is implemented. Use the command in the basic rules.
- Debug all implemented test cases and confirm execution.
- After all processes are complete, review implementation and design document for requirements and quality.
- If review finds no problems, compare implementation and design document; if there are differences, update the design document.

---
