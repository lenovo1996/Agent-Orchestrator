# PHP8 Dev-Team Flow Orchestrator

README này mô tả cách setup và vận hành dev-team flow orchestrator trong repo, gồm Codex workflow, tmux dashboard, task-flow storage, MCP servers, Jira MCP, Bitbucket MCP, và các lệnh thường dùng.

## 1. Tổng quan

Dev-team orchestrator là workflow nhiều agent chạy tuần tự để xử lý Jira task trong repo.

Flow hiện tại:

```text
Clarifier → Architect → Task Breaker → Planner → Implementer → Reviewer → QA
```

Mỗi step sinh output riêng trong task-flow folder:

```text
clarifier   → clarify.md
architect   → architecture.md
taskbreaker → tasks.md
planner     → plan.md
implementer → implementation.md
reviewer    → review.md
qa          → qa.md
```

Runtime chính:

- Orchestrator: Node.js scripts trong `.dev-team/scripts`
- Worker model: Codex CLI
- Default model: `gpt-5.5`
- Reasoning: `high`
- Dashboard: tmux + Python live dashboard
- Logs: `.dev-team/task-flows/<FLOW_ID>/logs/`
- MCP: configured qua `.mcp.json`
- Jira: dùng project-local MCP server trong `.dev-team/agents/jira`; CLI vẫn dùng được khi cần thao tác thủ công
- Bitbucket: dùng project-local MCP server trong `.dev-team/agents/bitbucket`

## 2. Folder structure

```text
.dev-team/
├── agents/
│   ├── bitbucket/
│   │   ├── server.js
│   │   ├── package.json
│   │   ├── package-lock.json
│   │   ├── README.md
│   │   ├── .env                 # credentials, ignored by git
│   │   └── node_modules/        # ignored by git
│   └── jira/
│       ├── server.js
│       ├── package.json
│       ├── package-lock.json
│       ├── README.md
│       ├── .env.example         # credential template, safe to commit
│       ├── .env                 # credentials, ignored by git
│       └── node_modules/        # ignored by git
├── prompts/
│   ├── clarifier.md
│   ├── architect.md
│   ├── taskbreaker.md
│   ├── planner.md
│   ├── implementer.md
│   ├── reviewer.md
│   └── qa.md
├── scripts/
│   ├── start-with-monitor.sh
│   ├── monitor-existing.sh
│   ├── orchestrator.js
│   ├── spawn-via-gateway.js
│   ├── watcher.js
│   ├── codex-agent-wrapper.sh
│   ├── dashboard.py
│   └── log-pretty.py
├── task-flows/                  # runtime outputs, ignored by git
├── team.json
└── .gitignore
```

Top-level files:

```text
.mcp.json                         # MCP servers for Codex
README.md                         # this file
```

## 3. Prerequisites

### 3.1 Required binaries

Check:

```bash
command -v node
command -v npm
command -v npx
command -v uvx
command -v tmux
command -v python3
command -v jq
command -v git
command -v codex
```

Expected examples:

```text
node    → Node.js v22+
npm     → Node package manager
npx     → for filesystem MCP
uvx     → for git MCP
tmux    → dashboard panes
python3 → dashboard/log pretty scripts
jq      → workflow/status formatting
codex   → agent runtime
```

### 3.2 Codex account/model

Current tested Codex config:

```text
model: gpt-5.5
reasoning effort: high
```

## 4. Install / restore setup

Run from repo root:

```bash
cd /path/to/project
```

### 4.1 Install MCP dependencies

```bash
cd .dev-team/agents/bitbucket
npm ci
cd ../../..

cd .dev-team/agents/jira
npm ci
cd ../../..
```

### 4.2 Install Python dependencies

Dashboard requires `wcwidth`:

```bash
pip3 install wcwidth
```

Or with `pipx`:

```bash
pipx install wcwidth
```

Or system package manager:

```bash
# Ubuntu/Debian
sudo apt install python3-wcwidth

# macOS
brew install python3
pip3 install wcwidth
```

### 4.3 Ensure scripts are executable

```bash
chmod +x .dev-team/scripts/*.sh
chmod +x .dev-team/agents/bitbucket/server.js
chmod +x .dev-team/agents/jira/server.js
```

### 4.4 Setup shell aliases

Add to `~/.zshrc`:

```bash
alias devteam-start='bash $(pwd)/.dev-team/scripts/start-with-monitor.sh'
alias devteam-monitor='bash $(pwd)/.dev-team/scripts/monitor-existing.sh'
```

Apply current shell:

```bash
source ~/.zshrc
```

Then use:

```bash
devteam-start JH-40502 --prompt 'custom instruction here'
devteam-start --prompt 'custom task without Jira key'
devteam-monitor flow_20260602144918_JH-40502
```

## 5. Configuration files

### 5.1 `.dev-team/team.json`

Main orchestrator config:

```json
{
  "repoRoot": "<REPO_ROOT>",
  "defaultBranchPrefix": "feature",
  "outputRoot": "<REPO_ROOT>/.dev-team/task-flows",
  "members": {
    "clarifier": { "model": "gpt-5.5", "thinking": "xhigh" },
    "architect": { "model": "gpt-5.5", "thinking": "high" },
    "taskbreaker": { "model": "gpt-5.5", "thinking": "high" },
    "planner": { "model": "gpt-5.5", "thinking": "high" },
    "implementer": { "runtime": "codex", "model": "gpt-5.5", "thinking": "high" },
    "reviewer": { "model": "gpt-5.5", "thinking": "xhigh" },
    "qa": { "model": "gpt-5.5", "thinking": "high" }
  }
}
```

Important fields:

- `repoRoot`: PHP8 repo root.
- `outputRoot`: all task-flow runtime outputs.
- `members`: step definition, objective, model, thinking, expected outputs.

### 5.2 `.mcp.json`

Current MCP config:

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "<REPO_ROOT>"
      ]
    },
    "git": {
      "command": "uvx",
      "args": [
        "mcp-server-git",
        "--repository",
        "<REPO_ROOT>"
      ]
    },
    "bitbucket": {
      "command": "node",
      "args": [
        "<REPO_ROOT>/.dev-team/agents/bitbucket/server.js"
      ]
    },
    "jira": {
      "command": "node",
      "args": [
        "<REPO_ROOT>/.dev-team/agents/jira/server.js"
      ]
    }
  }
}
```

Active MCP servers:

| Server | Purpose | Status |
|---|---|---|
| `filesystem` | read/write repo files | active |
| `git` | git status/diff/log/branch tools | active |
| `bitbucket` | Bitbucket PR metadata/diff/comments/approval | active |
| `jira` | Jira issue metadata/comments/transitions | active |

## 6. MCP setup and testing

### 6.1 Filesystem MCP

Command:

```bash
npx -y @modelcontextprotocol/server-filesystem <REPO_ROOT>
```

Useful tools exposed:

```text
read_text_file
read_multiple_files
write_file
edit_file
list_directory
directory_tree
search_files
get_file_info
list_allowed_directories
```

### 6.2 Git MCP

Command:

```bash
uvx mcp-server-git --repository <REPO_ROOT>
```

Useful tools exposed:

```text
git_status
git_diff_unstaged
git_diff_staged
git_diff
git_log
git_branch
git_checkout
git_create_branch
git_add
git_commit
git_reset
git_show
```

### 6.3 Bitbucket MCP

Local path:

```text
<REPO_ROOT>/.dev-team/agents/bitbucket/server.js
```

Auth file:

```text
<REPO_ROOT>/.dev-team/agents/bitbucket/.env
```

Never print `.env` values.

Tools exposed:

```text
parse_pr_url
get_pullrequest
get_diff
get_diffstat
get_tasks
add_comment
approve
create_pullrequest
```

Read operations are OK for context gathering.

Write operations require explicit confirmation:

- `add_comment`
- `approve`
- `create_pullrequest`

### 6.4 Jira MCP

Local path:

```text
<REPO_ROOT>/.dev-team/agents/jira/server.js
```

Credentials are read from `.dev-team/agents/jira/.env`.

Template:

```text
<REPO_ROOT>/.dev-team/agents/jira/.env.example
```

Never print `.env`, Jira config, token, or password values.

Tools exposed:

```text
search_issues
get_issue
get_comments
create_issue
list_transitions
transition_issue
add_comment
```

Read operations are OK for context gathering.

Write operations require explicit confirmation:

- `create_issue`
- `transition_issue`
- `add_comment`

### 6.5 Test MCP servers manually

From repo root:

```bash
cd /path/to/project
```

Test initialize:

```bash
timeout 3 npx -y @modelcontextprotocol/server-filesystem <REPO_ROOT> <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

```bash
timeout 3 uvx mcp-server-git --repository <REPO_ROOT> <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

```bash
timeout 3 node .dev-team/agents/bitbucket/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

```bash
timeout 3 node .dev-team/agents/jira/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

Expected:

```text
filesystem → secure-filesystem-server
Git        → mcp-git
Bitbucket  → mcp-bitbucket-cloud
Jira       → mcp-jira-cloud-local
```

Test tool listing:

```bash
node .dev-team/agents/bitbucket/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
EOF
```

```bash
node .dev-team/agents/jira/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
EOF
```


## 8. Confluence integration

No dedicated Confluence MCP.

Use REST API with Jira credentials from:

```text
.dev-team/agents/jira/.env
```

Base:

```text
https://your-space.atlassian.net/wiki
```

Useful endpoints:

```text
GET /wiki/api/v2/spaces?limit=20
GET /wiki/api/v2/pages/{page_id}?body-format=storage
GET /wiki/rest/api/search?cql=siteSearch ~ "keyword"&limit=25&expand=content.space,content.version
```

Never print API token.

Prefer writing local context into:

```text
.dev-team/task-flows/<FLOW_ID>/context.md
```

Do not edit Confluence unless explicitly requested.

## 9. Starting a new dev-team flow

Basic:

```bash
devteam-start JH-40502
```

With custom prompt:

```bash
devteam-start JH-40502 --prompt 'Write unit tests for all changed behavior'

Ad-hoc flow without Jira key:

```bash
devteam-start --prompt 'Investigate flaky tests and suggest fixes'
```
```

Equivalent full path:

```bash
bash .dev-team/scripts/start-with-monitor.sh JH-40502 --prompt 'Write unit tests'
```

What happens:

1. `orchestrator.js start` creates a new flow folder.
2. `spawn-via-gateway.js` starts `clarifier`.
3. `watcher.js` watches outputs and auto-spawns next steps.
4. tmux dashboard opens.
5. Logs stream through `log-pretty.py`.
6. Each agent writes its output markdown.

Flow ID format:

```text
flow_YYYYmmddHHMMSS
flow_YYYYmmddHHMMSS_JH-40502
```

Flow directory example:

```text
.dev-team/task-flows/flow_20260602144918_JH-40502/
├── workflow.json
├── clarify.md
├── architecture.md
├── tasks.md
├── plan.md
├── implementation.md
├── review.md
├── qa.md
├── logs/
│   ├── current.log -> <current-agent>.log
│   ├── clarifier.log
│   ├── architect.log
│   ├── taskbreaker.log
│   ├── planner.log
│   ├── implementer.log
│   ├── reviewer.log
│   └── qa.log
└── tmux-helper.sh
```

## 10. Monitoring existing flow

Use:

```bash
devteam-monitor flow_20260602144918_JH-40502
```

Equivalent full path:

```bash
bash .dev-team/scripts/monitor-existing.sh flow_20260602144918_JH-40502
```

Behavior:

- Verifies flow directory exists.
- Verifies `workflow.json` exists.
- Auto-starts watcher if missing.
- Reattaches existing tmux session if present.
- Creates tmux dashboard if not present.

List recent flows manually:

```bash
ls -1dt <REPO_ROOT>/.dev-team/task-flows/flow_* | head -10
```

## 11. tmux dashboard layout

Pane purpose:

| Pane | Purpose |
|---|---|
| top-left | dashboard.py agent status |
| top-right | manual Codex CLI shell |
| bottom-left | pretty live log |
| bottom-right | helper menu |

Useful tmux controls:

**Pane navigation (automatic setup):**
```text
Alt + arrow keys        → switch pane (easiest)
Ctrl + arrow keys       → switch pane (alternative)
Click with mouse        → switch pane (mouse enabled)
Ctrl+B then arrow keys  → classic tmux navigation
```

**Other controls:**
```text
Ctrl+B then [           → scroll mode
q                       → exit scroll mode
Ctrl+B then d           → detach
Ctrl+B then o           → cycle next pane
Ctrl+B then q           → show pane numbers, press number to jump
```

Reattach:

```bash
tmux attach-session -t devteam_<FLOW_ID>
```

Example:

```bash
tmux attach-session -t devteam_flow_20260602144918_JH-40502
```

Kill/restart dashboard session:

```bash
tmux kill-session -t devteam_flow_20260602144918_JH-40502
devteam-monitor flow_20260602144918_JH-40502
```

## 12. Helper pane commands

The helper pane supports:

```text
1) View clarify.md
2) View architecture.md
3) View tasks.md
4) View plan.md
5) View implementation.md
6) View review.md
7) View qa.md
s) status
r) retry step
R) retry step + clear output file
q) quit helper
```

Retry step choices:

```text
clarifier
architect
taskbreaker
planner
implementer
reviewer
qa
```

`r` retries without deleting output.

`R` deletes the step output first, then respawns.

Output files cleared by `R`:

```text
clarifier   → clarify.md
architect   → architecture.md
taskbreaker → tasks.md
planner     → plan.md
implementer → implementation.md
reviewer    → review.md
qa          → qa.md
```

## 13. Watcher behavior

`watcher.js` watches the workflow and outputs.

Main behavior:

- Parses each output file status.
- Treats output as `DONE` if status marker says DONE.
- If output exists and status is DONE, skips duplicate spawn.
- Auto-spawns next step after current step completes.
- Retries failed step once.

Current retry config:

```js
const MAX_RETRIES = 1;
```

Failure behavior:

```text
FAILED → retry same step once → if still FAILED, mark workflow failed and stop
```

Current limitation:

- No rollback to `reviewer` or `implementer` after QA failure yet.
- QA rollback policy must be designed separately if needed.

## 14. Log handling

Each Codex agent log is stored under:

```text
.dev-team/task-flows/<FLOW_ID>/logs/<agent>.log
```

Current active log symlink:

```text
.dev-team/task-flows/<FLOW_ID>/logs/current.log
```

`log-pretty.py` follows `current.log` and reopens when symlink target changes.

It prettifies noisy logs:

- Collapses tool calls to one line.
- Shows file reads with relative paths.
- Collapses long output.
- Highlights errors.
- Collapses noisy `rg -n`, `grep -n`, and `find` output summaries.

## 15. Dashboard terminal safety

`dashboard.py` disables terminal modes that can leak raw escape strings into pane after finish/click/scroll:

```text
?1000  mouse tracking
?1002  mouse drag tracking
?1003  all motion tracking
?1006  SGR mouse mode
?1015  urxvt mouse mode
?2004  bracketed paste
?25h   show cursor
```

If terminal shows raw strings like:

```text
<64;177;27M
```

Restart dashboard session:

```bash
tmux kill-session -t devteam_<FLOW_ID>
devteam-monitor <FLOW_ID>
```

## 16. Codex wrapper

Wrapper:

```text
.dev-team/scripts/codex-agent-wrapper.sh
```

Expected behavior:

- Runs Codex from repo root.
- Uses model from team config, default `gpt-5.5`.
- Uses reasoning from team config, default `high`.
- Uses dangerous full access because this project flow needs filesystem/git/MCP/Jira capability.

Expected Codex header:

```text
model: gpt-5.5
approval: never
sandbox: danger-full-access
reasoning effort: high
```

If reasoning shows `none`, check wrapper config key:

```bash
-c "model_reasoning_effort=\"$CODEX_REASONING\""
```

## 17. Security and git ignore

`.dev-team/.gitignore` ignores runtime/secrets:

```gitignore
agents/*/.env
agents/*/node_modules/
task-flows/
scripts/__pycache__/
*.pyc
```

Important:

- Do not commit `.dev-team/agents/bitbucket/.env`.
- Do not commit `.dev-team/agents/jira/.env`.
- Do not print Jira token/password.
- Do not print Bitbucket app password.
- Do not approve/comment/create PR unless user explicitly asks.
- Do not create/transition/comment Jira unless user explicitly asks.
- Reads are allowed for implementation context.

Check what would be committed:

```bash
git status --short .dev-team/ .mcp.json README.md
```

Check ignore:

```bash
git check-ignore -v .dev-team/agents/bitbucket/.env
git check-ignore -v .dev-team/agents/jira/.env
```

## 18. Common commands

Start flow:

```bash
devteam-start JH-40502
```

Start with instruction:

```bash
devteam-start JH-40502 --prompt 'Focus on regression tests and API compatibility'
```

Monitor existing:

```bash
devteam-monitor flow_20260602144918_JH-40502
```

Show workflow status:

```bash
node .dev-team/scripts/orchestrator.js status flow_20260602144918_JH-40502
```

Spawn/retry specific step:

```bash
node .dev-team/scripts/spawn-via-gateway.js flow_20260602144918_JH-40502 reviewer
```

Start watcher manually:

```bash
node .dev-team/scripts/watcher.js flow_20260602144918_JH-40502
```

View logs:

```bash
python3 .dev-team/scripts/log-pretty.py .dev-team/task-flows/flow_20260602144918_JH-40502/logs/current.log
```

List flows:

```bash
ls -1dt .dev-team/task-flows/flow_* | head -10
```

View output:

```bash
less .dev-team/task-flows/<FLOW_ID>/clarify.md
less .dev-team/task-flows/<FLOW_ID>/architecture.md
less .dev-team/task-flows/<FLOW_ID>/tasks.md
less .dev-team/task-flows/<FLOW_ID>/plan.md
less .dev-team/task-flows/<FLOW_ID>/implementation.md
less .dev-team/task-flows/<FLOW_ID>/review.md
less .dev-team/task-flows/<FLOW_ID>/qa.md
```

## 19. Troubleshooting

### 19.1 MCP Bitbucket fails

Check files:

```bash
test -f .dev-team/agents/bitbucket/server.js
test -f .dev-team/agents/bitbucket/.env
test -d .dev-team/agents/bitbucket/node_modules
```

Reinstall deps:

```bash
cd .dev-team/agents/bitbucket
npm ci
```

Test initialize:

```bash
cd /path/to/project
timeout 3 node .dev-team/agents/bitbucket/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

### 19.2 MCP Jira fails

Check files:

```bash
test -f .dev-team/agents/jira/server.js
test -f .dev-team/agents/jira/.env.example
test -d .dev-team/agents/jira/node_modules
```

Check credentials from either local `.env`:

```bash
test -f .dev-team/agents/jira/.env
```

Reinstall deps:

```bash
cd .dev-team/agents/jira
npm ci
```

Test initialize:

```bash
cd /path/to/PHP8
timeout 3 node .dev-team/agents/jira/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

Test read operation:

```bash
node .dev-team/agents/jira/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"get_issue","arguments":{"issueKey":"JH-40500"}}}
EOF
```

### 19.4 Codex model error

If log shows:

```text
The 'cx/gpt-5.5' model is not supported when using Codex with a ChatGPT account.
```

Fix `team.json`/wrapper model to:

```text
gpt-5.5
```

### 19.5 Codex reasoning is none

If log shows:

```text
reasoning effort: none
```

Check wrapper uses:

```bash
-c "model_reasoning_effort=\"high\""
```

### 19.6 Dashboard layout wrong

Expected:

```text
Top: dashboard | codex
Bottom: live log | helper
```

Restart:

```bash
tmux kill-session -t devteam_<FLOW_ID>
devteam-monitor <FLOW_ID>
```

Inspect pane geometry:

```bash
tmux list-panes -t devteam_<FLOW_ID>:0 -F '#{pane_index} #{pane_id} #{pane_width}x#{pane_height} #{pane_left},#{pane_top}'
```

### 19.7 Watcher not running

`monitor-existing.sh` auto-starts watcher.

Manual check:

```bash
pgrep -af 'watcher.js <FLOW_ID>'
```

Manual start:

```bash
nohup node .dev-team/scripts/watcher.js <FLOW_ID> > .dev-team/task-flows/<FLOW_ID>/logs/watcher.log 2>&1 &
```

### 19.8 Existing output causes duplicate spawn

Watcher checks existing outputs. If output exists and status is DONE, it skips duplicate spawn.

To force retry and clear old output, use helper pane `R`.

## 20. Development notes

### 20.1 Install parallel worktree dependencies

```bash
cd .dev-team/scripts
npm install
```

This installs `fast-check` for property-based testing.

### 20.2 General development checks

### 20.2 General development checks

When editing orchestrator code:

Run syntax checks:

```bash
bash -n .dev-team/scripts/*.sh
node -c .dev-team/scripts/orchestrator.js
node -c .dev-team/scripts/spawn-via-gateway.js
node -c .dev-team/scripts/watcher.js
python3 -m py_compile .dev-team/scripts/dashboard.py .dev-team/scripts/log-pretty.py
```

Check MCP config:

```bash
cat .mcp.json | jq .
```

Check team config:

```bash
cat .dev-team/team.json | jq .
```

## 21. Parallel Worktree Tasks

Hệ thống hỗ trợ chạy song song nhiều task flow bằng git worktree. Mỗi implementer task được cô lập trong một worktree riêng biệt, cho phép nhiều agent hoạt động đồng thời trên cùng repository.

### 21.1 Cấu hình

Thêm key `worktree` vào `.dev-team/team.json`:

```json
{
  "worktree": {
    "enabled": true,
    "baseDir": "../.dev-team-worktrees",
    "maxConcurrency": 3,
    "defaultRepos": [
      "jinjer_hr_core",
      "jinjer_hr_auth",
      "jinjer_hr_authentication",
      "jinjer_hr_jinji"
    ],
    "repos": {
      "jinjer_hr_core": "./jinjer_hr_core",
      "jinjer_hr_auth": "./jinjer_hr_auth",
      "jinjer_hr_authentication": "./jinjer_hr_authentication",
      "jinjer_hr_jinji": "./jinjer_hr_jinji"
    }
  }
}
```

| Key | Mô tả | Default |
|---|---|---|
| `enabled` | Bật/tắt parallel mode | `false` |
| `baseDir` | Thư mục lưu worktrees | `../.dev-team-worktrees` |
| `maxConcurrency` | Số task chạy đồng thời tối đa | `3` |
| `defaultRepos` | Fallback repos khi auto-detect thất bại | `[]` |
| `repos` | Mapping tên repo → local path | `{}` |

### 21.2 Sử dụng Orchestrator (parallel mode)

**Auto-detect repos (khuyến nghị):**

Sau khi architect step hoàn thành, dùng `parallel auto` để tự động detect repos từ `architecture.md` và schedule implementer cho mỗi repo:

```bash
node .dev-team/scripts/orchestrator.js parallel auto <flow-id>
```

Ví dụ:

```bash
node .dev-team/scripts/orchestrator.js parallel auto flow_20260605_JH-40515
```

Output:

```text
🔍 Detected 2 repo(s) for flow flow_20260605_JH-40515:
   - jinjer_hr_core
   - jinjer_hr_jinji

🚀 Scheduled implementer for flow_20260605_JH-40515 (running immediately)
   Repo: jinjer_hr_core
🚀 Scheduled implementer for flow_20260605_JH-40515 (running immediately)
   Repo: jinjer_hr_jinji
```

Logic detect:
1. Parse section `## Impacted Repos/Modules` trong `architecture.md`
2. Extract repo names từ file paths (prefix trước `/` đầu tiên)
3. Validate against repos trong `team.json` config
4. Nếu không detect được → fallback sang `defaultRepos` (cả 4 repo)

**Schedule thủ công (chỉ định repo):**

```bash
node .dev-team/scripts/orchestrator.js parallel schedule <flow-id> <repo-name>
```

Ví dụ:

```bash
node .dev-team/scripts/orchestrator.js parallel schedule flow_20260605_JH-40515 jinjer_hr_core
```

Xem trạng thái scheduler:

```bash
node .dev-team/scripts/orchestrator.js parallel status
```

### 21.3 Worktree CLI

CLI quản lý worktrees:

```bash
node .dev-team/scripts/worktree-cli.js <command> [options]
```

Commands:

| Command | Mô tả |
|---|---|
| `list` | Hiển thị tất cả worktrees đang theo dõi |
| `cleanup` | Xóa worktrees đã hoàn thành/thất bại |
| `merge <flow-id>` | Merge branch của flow vào target branch |
| `status` | Hiển thị trạng thái parallel scheduler |
| `help` | Hiện hướng dẫn |

Ví dụ:

```bash
# Xem danh sách worktrees
node .dev-team/scripts/worktree-cli.js list

# Dọn dẹp worktrees đã xong
node .dev-team/scripts/worktree-cli.js cleanup

# Merge kết quả (dry-run trước)
node .dev-team/scripts/worktree-cli.js merge flow_20260605_JH-40515 --dry-run
node .dev-team/scripts/worktree-cli.js merge flow_20260605_JH-40515 --target main

# Xem scheduler status
node .dev-team/scripts/worktree-cli.js status
```

### 21.4 Watcher (parallel mode)

Monitor nhiều flow đồng thời:

```bash
node .dev-team/scripts/watcher.js --parallel [interval-ms]
```

Ví dụ:

```bash
node .dev-team/scripts/watcher.js --parallel 3000
```

Behavior trong parallel mode:

- Đọc `.dev-team/parallel-status.json` để lấy danh sách active flows
- Report status với prefix `[flow_id]` cho mỗi flow
- Nếu một flow gặp NEEDS_FIX → chỉ trigger fix loop cho flow đó, không ảnh hưởng các flow khác
- Khi tất cả flows hoàn thành → emit summary: pass/fail count + elapsed time

### 21.5 Workflow song song

```text
1. orchestrator.js parallel schedule flow_A jinjer_hr_core
   → Scheduler assign worktree, spawn agent

2. orchestrator.js parallel schedule flow_B jinjer_hr_auth
   → Nếu còn slot: spawn ngay. Nếu đầy: queue (FIFO)

3. Mỗi agent chạy trong worktree cô lập:
   ../.dev-team-worktrees/{flowId}/{step}/

4. Khi task xong → slot giải phóng → dequeue task tiếp theo

5. worktree-cli.js merge <flow-id> → merge kết quả về branch chính

6. worktree-cli.js cleanup → dọn dẹp worktrees đã merge
```

### 21.6 File structure (parallel mode)

```text
.dev-team/
├── scripts/
│   ├── lib/
│   │   ├── worktree-manager.js    # Quản lý lifecycle git worktree
│   │   ├── parallel-scheduler.js  # Scheduling song song + FIFO queue
│   │   └── branch-resolver.js     # Resolve branch naming convention
│   ├── worktree-cli.js            # CLI: list/cleanup/merge/status
│   └── ...
├── parallel-status.json           # Runtime state (running/queued/completed)
└── team.json                      # Config (worktree key)

../.dev-team-worktrees/            # Worktree storage (bên ngoài repo)
├── flow_20260605_JH-40515/
│   └── implementer/              # Git worktree cho flow này
└── flow_20260605_JH-40516/
    └── implementer/
```

### 21.7 Testing

Chạy toàn bộ test suite:

```bash
node --test .dev-team/scripts/test/**/*.test.js
```

Test suite bao gồm:
- Property-based tests (fast-check, 18 properties, 100 iterations mỗi property)
- Unit tests cho edge cases và error handling
- Tổng: 236 tests

## 22. Current known limitations

- QA failure currently retries QA once, then stops workflow. No automatic rollback to implementer/reviewer yet.
- Dashboard layout should be verified with real tmux geometry after layout code changes.
- Task-flow runtime files are ignored and not intended for commit.
- Bitbucket MCP has write tools, but writes must be user-approved.
- Jira MCP has write tools, but writes must be user-approved.
- Parallel mode: queued tasks chỉ được tự động spawn khi orchestrator process còn chạy. Nếu orchestrator bị kill, dùng `orchestrator.js parallel status` để kiểm tra và reschedule.
- Merge conflicts cần user giải quyết thủ công (CLI báo conflict files).

## 23. Quick start

```bash
cd /path/to/PHP8
source ~/.zshrc

devteam-start JH-40502 --prompt 'Clarify requirements, implement safely, run tests, and prepare QA summary'
```

Monitor later:

```bash
devteam-monitor flow_XXXXXXXXXX_JH-40502
```

Test MCP quickly:

```bash
timeout 3 node .dev-team/agents/bitbucket/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```

```bash
timeout 3 node .dev-team/agents/jira/server.js <<'EOF'
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}
EOF
```
